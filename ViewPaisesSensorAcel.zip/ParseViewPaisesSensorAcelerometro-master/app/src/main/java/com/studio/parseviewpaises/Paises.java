package com.studio.parseviewpaises;

public class Paises {

    private String nome;
    private String bandeira;
    private String Latitude;
    private  String Longetude;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBandeira() {
        return bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public String getLongetude() {
        return Longetude;
    }

    public void setLongetude(String longetude) {
        Longetude = longetude;
    }
}
