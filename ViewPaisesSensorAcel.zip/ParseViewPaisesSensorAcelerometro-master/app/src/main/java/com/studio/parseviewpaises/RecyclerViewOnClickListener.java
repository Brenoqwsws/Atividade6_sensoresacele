package com.studio.parseviewpaises;

import android.view.View;

public interface RecyclerViewOnClickListener {
    public void onClickListener(View view, int position);
}
